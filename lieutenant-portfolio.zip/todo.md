# Lieutenant.com Asset Update

- [ ] Upload Jatin’s supplied portrait to the web project asset store.
- [ ] Upload the four supplied certification images to the web project asset store.
- [ ] Replace the temporary hero image with Jatin’s portrait.
- [ ] Replace the About portrait slot with Jatin’s portrait or a cropped treatment of the supplied photo.
- [ ] Add the four real certificate images to the certifications section with readable titles.
- [ ] Replace placeholder GitHub and LinkedIn URLs.
- [ ] Add Instagram and YouTube links to the contact section.
- [ ] Run TypeScript and production builds.
- [ ] Visually verify the updated site and deliver the refreshed preview link.
