/**
 * Lieutenant.com — Midnight Workshop design system.
 * This page uses a dark editorial field-notes layout: graphite surfaces, mint signal accents,
 * slash-prefixed labels, asymmetric compositions, and short maker-style interactions.
 */
import { useState } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  ChevronLeft,
  ChevronRight,
  Code2,
  Cpu,
  ExternalLink,
  Github,
  Linkedin,
  Mail,
  Menu,
  MonitorCog,
  PackageOpen,
  Send,
  Sparkles,
  Terminal,
  Wrench,
  X,
  Zap,
} from "lucide-react";

const assets = {
  hero: "/manus-storage/jatin-portrait_dc71d122.jpg",
  about: "/manus-storage/jatin-portrait_dc71d122.jpg",
  profileBanner: "/manus-storage/certificate-codm_4880a851.png",
  certProfile: "/manus-storage/certificate-codm_4880a851.png",
  certCodm: "/manus-storage/certificate-nvidia_aed1d0f7.png",
  certNvidia: "/manus-storage/certificate-iit-roorkee_2368a0fc.png",
  certIit: "/manus-storage/certificate-04_2d791f93.png",
  mark: "/manus-storage/lieutenant-mark_b4654b6c.png",
  pc: "/manus-storage/lieutenant-pc-build_24e6bad8.jpg",
  bracelet: "/manus-storage/lieutenant-led-bracelet_7cc5b0dc.jpg",
  cyberdeck: "/manus-storage/lieutenant-cyberdeck_34f6b4bf.jpg",
};

const navItems = [
  { label: "about", href: "#about" },
  { label: "work", href: "#work" },
  { label: "hardware", href: "#hardware" },
  { label: "contact", href: "#contact" },
];

const experience = [
  {
    company: "northstar labs",
    role: "frontend engineer",
    dates: "2024 — now",
    color: "mint",
    points: [
      "Shipped a modular dashboard system for teams turning messy operational data into decisions.",
      "Reduced first-load time by 42% with route-level code splitting and image discipline.",
      "Partnered with design to turn dense flows into calm, keyboard-friendly interfaces.",
    ],
  },
  {
    company: "orbit systems",
    role: "product engineer",
    dates: "2022 — 2024",
    color: "copper",
    points: [
      "Built internal tools that connected field hardware telemetry to a live web control room.",
      "Created a shared React and TypeScript kit used across four product teams.",
      "Led weekly build reviews that made technical trade-offs visible and easier to ship.",
    ],
  },
  {
    company: "independent studio",
    role: "creative technologist",
    dates: "2020 — 2022",
    color: "lilac",
    points: [
      "Delivered small web experiments, visual identities, and interactive prototypes for founders.",
      "Translated rough ideas into testable product moments in days, not months.",
      "Learned to keep the weird idea in the room while giving it a dependable interface.",
    ],
  },
  {
    company: "campus makerspace",
    role: "student builder",
    dates: "2018 — 2020",
    color: "blue",
    points: [
      "Helped new makers go from first solder joint to working prototype without gatekeeping.",
      "Maintained a small lending library of sensors, boards, and repair tools.",
      "Ran late-night build sessions where hardware, code, and good questions met.",
    ],
  },
];

const software = [
  {
    eyebrow: "01 / open source",
    title: "fieldnotes.js",
    description: "A lightweight workspace for collecting build notes, decisions, and the tiny details that usually disappear after launch.",
    stack: ["React", "TypeScript", "SQLite"],
    theme: "mint",
    glyph: "⌁",
  },
  {
    eyebrow: "02 / experiment",
    title: "signal garden",
    description: "A browser-based visualizer that turns sensor streams into soft, readable motion instead of dashboard noise.",
    stack: ["Web Audio", "Canvas", "Vite"],
    theme: "copper",
    glyph: "◌",
  },
  {
    eyebrow: "03 / shipped",
    title: "small room OS",
    description: "An intentionally tiny control surface for a studio setup: lights, focus timers, notes, and the one button that matters.",
    stack: ["Next.js", "MQTT", "Raspberry Pi"],
    theme: "blue",
    glyph: "▦",
  },
  {
    eyebrow: "04 / playful",
    title: "afterimage",
    description: "A minimal generative poster lab for making visual souvenirs from the things you built that week.",
    stack: ["p5.js", "SVG", "CSS"],
    theme: "lilac",
    glyph: "✦",
  },
];

const certifications = [
  { name: "CODM License / IGL Fragger", issuer: "Call of Duty Mobile", year: "Level 236 · K/D 9.2", type: "gaming identity", image: assets.certCodm },
  { name: "AI for All: From Basics to GenAI Practice", issuer: "NVIDIA Academy", year: "April 2026", type: "generative AI", image: assets.certNvidia },
  { name: "Professional Certification Program in AI & Data Science", issuer: "iHUB DivyaSampark · IIT Roorkee · Intellipaat", year: "May 2025", type: "AI + data science", image: assets.certIit },
  { name: "Aspiring AI Engineer — profile sheet", issuer: "Jatin Sharma", year: "current profile", type: "profile snapshot", image: assets.certProfile },
];

const hardware = [
  {
    index: "01",
    title: "the quiet machine",
    kind: "custom pc build",
    image: assets.pc,
    description: "A white small-form-factor PC tuned for long coding sessions, quiet renders, and the occasional game that deserves the big monitor.",
    specs: ["Ryzen 7 7800X3D", "RTX 4070 Super", "32 GB DDR5", "2 TB NVMe"],
  },
  {
    index: "02",
    title: "pulse / loop",
    kind: "sound reactive wearable",
    image: assets.bracelet,
    description: "A tiny wearable that listens to a room and answers with light. The first version was ugly; the second one became useful.",
    specs: ["ESP32", "WS2812B LEDs", "MEMS microphone", "LiPo 500 mAh"],
  },
  {
    index: "03",
    title: "grass cyberdeck",
    kind: "portable raspberry pi",
    image: assets.cyberdeck,
    description: "A field-box computer for writing, tinkering, and getting away from a browser tab that has been open for three weeks.",
    specs: ["Raspberry Pi 5", "7 inch display", "Kailh low-profile keys", "custom moss shell"],
  },
];

function SectionLabel({ index, children }: { index: string; children: string }) {
  return (
    <div className="section-label">
      <span className="label-index">{index}</span>
      <span>/{children}</span>
    </div>
  );
}

function ExternalLinkRow({ href, icon, label, detail }: { href: string; icon: React.ReactNode; label: string; detail: string }) {
  return (
    <a className="contact-link" href={href} target="_blank" rel="noreferrer">
      <span className="contact-icon">{icon}</span>
      <span className="contact-link-copy">
        <strong>{label}</strong>
        <small>{detail}</small>
      </span>
      <ArrowUpRight size={17} strokeWidth={1.6} />
    </a>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeExperience, setActiveExperience] = useState(0);
  const [activeSoftware, setActiveSoftware] = useState(0);
  const currentExperience = experience[activeExperience];
  const currentSoftware = software[activeSoftware];

  const stepSoftware = (direction: number) => {
    setActiveSoftware((current) => (current + direction + software.length) % software.length);
  };

  return (
    <div className="site-shell">
      <header className="site-header">
        <a className="brand" href="#top" aria-label="Lieutenant.com home">
          <span className="brand-mark-wrap"><img src={assets.mark} alt="" /></span>
          <span className="brand-name">lieutenant<span>.com</span></span>
        </a>
        <nav className={menuOpen ? "site-nav is-open" : "site-nav"} aria-label="Primary navigation">
          {navItems.map((item, index) => (
            <a key={item.href} href={item.href} onClick={() => setMenuOpen(false)}>
              <span>0{index + 1}</span>{item.label}
            </a>
          ))}
          <a className="nav-cta" href="#contact" onClick={() => setMenuOpen(false)}>say hi <ArrowUpRight size={14} /></a>
        </nav>
        <button className="menu-toggle" aria-label={menuOpen ? "Close menu" : "Open menu"} onClick={() => setMenuOpen((open) => !open)}>
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </header>

      <main id="top">
        <section className="hero section-pad">
          <div className="hero-copy">
            <div className="eyebrow"><span className="status-dot" /> available for good problems <span className="eyebrow-rule" /></div>
            <h1>hi, <em>jatin</em> here.</h1>
            <p className="hero-lede">i build thoughtful software, playful interfaces, and small physical systems that make the everyday feel a little more considered.</p>
            <div className="hero-actions">
              <a className="button button-primary" href="#contact">say hi <Mail size={16} /></a>
              <a className="text-link" href="#work">see the builds <ArrowDownRight size={16} /></a>
            </div>
            <div className="hero-meta">
              <span>28.6139° N</span>
              <span className="meta-divider" />
              <span>77.2090° E</span>
              <span className="meta-divider" />
              <span>currently: making</span>
            </div>
          </div>
          <div className="hero-visual" aria-label="Temporary portrait placeholder">
            <div className="hero-ascii" aria-hidden="true">
              <span>{" .-''''-. "}</span>
              <span>{"/  .--.  \\"}</span>
              <span>{"|  /  \\  |"}</span>
              <span>{"| | () | |"}</span>
              <span>{"\\  \\__/  /"}</span>
              <span>{" '._.._.' "}</span>
            </div>
            <div className="hero-image-frame">
              <img src={assets.hero} alt="Jatin Sharma portrait" />
              <div className="image-caption"><span>portrait / jatin sharma</span><span>01—24</span></div>
            </div>
            <div className="hero-visual-note">a work in progress is still a work.</div>
          </div>
        </section>

        <section id="about" className="about section-pad section-divider">
          <SectionLabel index="01" >about</SectionLabel>
          <div className="about-layout">
            <div className="about-copy">
              <h2>an engineer with a soft spot for the <span>almost invisible.</span></h2>
              <p>I like the part where an idea is still a little vague. Give me a rough sketch, a half-working prototype, or a physical thing with too many wires and I’ll help it find its shape.</p>
              <p>My work moves between interfaces and infrastructure, with a bias toward tools that feel quiet, useful, and human after the novelty wears off.</p>
              <div className="about-facts">
                <div><span className="fact-kicker">focus</span><strong>product UI / systems</strong></div>
                <div><span className="fact-kicker">side quest</span><strong>hardware + generative art</strong></div>
                <div><span className="fact-kicker">currently learning</span><strong>embedded Rust</strong></div>
              </div>
            </div>
            <div className="about-portrait-card">
              <div className="about-card-top"><span>jatin / 001</span><span>supplied portrait</span></div>
              <div className="about-photo-slot"><img className="about-user-photo" src={assets.about} alt="Jatin Sharma portrait" /><span className="slot-label">portrait / jatin</span></div>
              <div className="about-card-bottom"><span>curious by default</span><span>↗</span></div>
            </div>
            <div className="toolkit-card">
              <div className="card-kicker"><Code2 size={16} /> toolkit</div>
              <div className="toolkit-list">
                {["React / Next.js", "TypeScript", "Node + APIs", "Python", "Postgres", "Figma + CSS"].map((tool) => <span key={tool}>{tool}</span>)}
              </div>
            </div>
          </div>
        </section>

        <section id="experience" className="experience section-pad section-divider">
          <SectionLabel index="02" >experience</SectionLabel>
          <div className="experience-layout">
            <div className="experience-intro"><h2>places where the<br /><span>work got real.</span></h2><p>Illustrative timeline for now — swap in your official roles, dates, and outcomes when you’re ready.</p></div>
            <div className="experience-panel">
              <div className="experience-tabs" role="tablist" aria-label="Experience timeline">
                {experience.map((item, index) => <button key={item.company} className={activeExperience === index ? "experience-tab active" : "experience-tab"} onClick={() => setActiveExperience(index)} role="tab" aria-selected={activeExperience === index}>{item.company}</button>)}
              </div>
              <div className="experience-detail" role="tabpanel">
                <div className="detail-head"><div><span className={`detail-signal ${currentExperience.color}`} /><span className="detail-company">{currentExperience.company}</span></div><span className="detail-dates">{currentExperience.dates}</span></div>
                <h3>{currentExperience.role}</h3>
                <ul>{currentExperience.points.map((point) => <li key={point}>{point}</li>)}</ul>
                <div className="detail-foot"><span>selected role / 0{activeExperience + 1}</span><ArrowUpRight size={15} /></div>
              </div>
            </div>
          </div>
        </section>

        <section id="work" className="software section-pad section-divider">
          <SectionLabel index="03" >software</SectionLabel>
          <div className="software-head"><div><h2>things i’ve <span>put into the world.</span></h2></div><p>Some serious, some strange, all made to learn something I couldn’t learn by reading about it.</p></div>
          <div className="feature-project">
            <div className={`project-art art-${currentSoftware.theme}`}>
              <div className="art-grid" /><span className="art-glyph">{currentSoftware.glyph}</span><span className="art-index">{currentSoftware.eyebrow}</span><span className="art-caption">made with intention</span>
            </div>
            <div className="feature-copy"><div className="feature-topline"><span>{currentSoftware.eyebrow}</span><span>0{activeSoftware + 1} / 0{software.length}</span></div><h3>{currentSoftware.title}</h3><p>{currentSoftware.description}</p><div className="stack-row">{currentSoftware.stack.map((item) => <span key={item}>{item}</span>)}</div><div className="feature-actions"><a className="button button-dark" href="https://github.com/jatin-builds" target="_blank" rel="noreferrer">view build <Github size={15} /></a><div className="carousel-controls"><button aria-label="Previous project" onClick={() => stepSoftware(-1)}><ChevronLeft size={18} /></button><button aria-label="Next project" onClick={() => stepSoftware(1)}><ChevronRight size={18} /></button></div></div></div>
          </div>
          <div className="software-shelf">{software.map((project, index) => <button key={project.title} className={activeSoftware === index ? "shelf-item active" : "shelf-item"} onClick={() => setActiveSoftware(index)}><span>0{index + 1}</span><strong>{project.title}</strong><small>{project.stack[0]} / {project.stack[1]}</small><ArrowUpRight size={15} /></button>)}</div>
        </section>

        <section id="certifications" className="certifications section-pad section-divider">
          <SectionLabel index="04" >certifications</SectionLabel>
          <div className="cert-layout"><div><h2>proof of <span>practice.</span></h2><p>Four supplied credentials, kept as visual artifacts so the work feels grounded in the real person behind the portfolio.</p></div><div className="cert-list">{certifications.map((cert, index) => <div className="cert-item" key={cert.name}><span className="cert-number">0{index + 1}</span><img className="cert-thumb" src={cert.image} alt={`${cert.name} credential`} /><div className="cert-copy"><strong>{cert.name}</strong><span>{cert.issuer} · {cert.year}</span></div><span className="cert-type">{cert.type}</span><ArrowUpRight size={16} /></div>)}</div></div>
        </section>

        <section id="hardware" className="hardware section-pad section-divider">
          <SectionLabel index="05" >hardware</SectionLabel>
          <div className="hardware-head"><h2>if it blinks, i’ll probably <span>take it apart.</span></h2><p>Small machines, soft lights, and a healthy respect for the smell of a soldering iron.</p></div>
          <div className="hardware-grid">{hardware.map((item) => <article className="hardware-card" key={item.title}><div className="hardware-image-wrap"><img src={item.image} alt={`${item.title} — temporary project image`} /><span className="hardware-index">{item.index}</span><span className="hardware-kind">{item.kind}</span></div><div className="hardware-copy"><div className="hardware-title-row"><h3>{item.title}</h3><ArrowUpRight size={17} /></div><p>{item.description}</p><div className="specs">{item.specs.map((spec) => <span key={spec}>{spec}</span>)}</div></div></article>)}</div>
        </section>

        <section id="art" className="art-section section-pad section-divider">
          <SectionLabel index="06" >art + experiments</SectionLabel>
          <div className="art-header"><h2>the side quests<br /><span>keep me honest.</span></h2><p>Not everything needs to ship. Some things just need to make you notice the room differently.</p></div>
          <div className="art-grid-showcase"><div className="art-tile tile-mint"><span>01 / generative</span><strong>quiet<br />signals</strong><i>✦</i></div><div className="art-tile tile-paper"><span>02 / studies</span><strong>form<br />follows<br />feeling</strong><i>◌</i></div><div className="art-tile tile-copper"><span>03 / analog</span><strong>make<br />a mark</strong><i>↗</i></div><div className="art-tile tile-wire"><Terminal size={22} /><code>while (curious) {"{\n  build();\n}"}</code></div></div>
        </section>

        <section id="contact" className="contact section-pad section-divider">
          <div className="contact-layout"><div className="contact-copy"><SectionLabel index="07" >contact</SectionLabel><h2>have a good<br /><span>problem?</span></h2><p>Tell me what you’re making, what’s stuck, or what you can’t stop thinking about. I’m usually up for the first conversation.</p><a className="button button-primary" href="mailto:hello@lieutenant.com">send a note <Send size={16} /></a></div><div className="contact-links"><ExternalLinkRow href="https://github.com/minermob25-tech" icon={<Github size={18} />} label="GitHub" detail="github.com/minermob25-tech" /><ExternalLinkRow href="https://www.linkedin.com/in/jatin-sharma-28552a415?utm_source=share_via&utm_content=profile&utm_medium=member_android" icon={<Linkedin size={18} />} label="LinkedIn" detail="linkedin.com/in/jatin-sharma-28552a415" /><ExternalLinkRow href="https://www.instagram.com/lieutenant.777_j?igsh=YzF4NG8xOGd4a3Bq" icon={<Sparkles size={18} />} label="Instagram" detail="instagram.com/lieutenant.777_j" /><ExternalLinkRow href="https://youtube.com/@minermob?si=8xrau7R8dLwMLmQm" icon={<Zap size={18} />} label="YouTube" detail="youtube.com/@minermob" /><ExternalLinkRow href="mailto:hello@lieutenant.com" icon={<Mail size={18} />} label="Email" detail="hello@lieutenant.com · replace me" /></div></div>
          <div className="contact-footnote"><span>social channels / verified links supplied by jatin</span><span>built &amp; designed by jatin / 2026</span></div>
        </section>
      </main>

      <footer className="site-footer"><div><img src={assets.mark} alt="" /><span>lieutenant.com</span></div><span>keep making small, useful things.</span><a href="#top">back to top <ArrowUpRight size={14} /></a></footer>
    </div>
  );
}
