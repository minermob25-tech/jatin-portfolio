# Lieutenant.com — Design Direction

## Reference Ground Truth

The supplied screen recording of gazijarin.com is the visual reference. The implementation should preserve its strongest design signals without copying personal content: a single-page dark portfolio, lowercase slash-prefixed section labels, mint/teal accents, generous vertical rhythm, a creative hero portrait treatment, concise intro copy, tabbed experience, featured software, hardware builds, a visual gallery, and a contact/footer close. Lieutenant.com replaces the reference identity and content with Jatin’s portfolio content.

## Chosen Direction: Midnight Workshop

### Design Movement
Contemporary digital editorial portfolio with a studio-workbench sensibility: dark graphite surfaces, technical annotations, mint signal color, and a blend of engineering precision with maker energy.

### Core Principles
1. **Quiet confidence:** large breathing room, short copy blocks, and restrained decoration let the work lead.
2. **Built, not merely listed:** projects, certifications, and hardware are presented as artifacts with context and metadata.
3. **Signal over noise:** mint marks active states, links, and key numbers; everything else stays in a graphite hierarchy.
4. **Human + technical:** the composition pairs a personable greeting and photo slot with systems diagrams, stack tags, and equipment specs.

### Color Philosophy
The base is near-black blue graphite (#0b1013) to make the page feel like a lit workbench after hours. A cool paper tone (#e9eee8) carries the reading surface. The signature color is **Lieutenant Mint (#a4f6c5)**: an ownable, high-contrast signal that feels like a status LED rather than a generic accent. Rust-copper (#d8895b) appears sparingly as a material counterpoint in hardware and project art.

### Layout Paradigm
A vertical, editorial field guide rather than a centered marketing grid. A persistent left rail anchors the page on wide screens, while the content shifts between split compositions, horizontal project shelves, tabbed timelines, and asymmetric hardware cards. On small screens the rail becomes a compact top bar and content collapses into readable single-column sections.

### Signature Elements
- Slash-prefixed section labels such as `/ about`, `/ certifications`, and `/ hardware`.
- Fine technical rules, small coordinate-like metadata, and a tiny mint status pulse.
- An ASCII-style monogram panel paired with the temporary portrait slot to echo the reference’s creative/technical bridge.

### Interaction Philosophy
Interactions should feel like inspecting a workbench: direct, legible, and responsive. Hovering reveals a little more context, tabs switch without visual jumpiness, project cards lift by a few pixels, and external links visibly announce themselves. Focus states are always visible.

### Animation
Use short 180–260ms ease-out transitions for controls, card lifts, underline sweeps, and tab changes. Add a subtle hero portrait drift and a slow signal pulse only when reduced motion is not requested. Avoid parallax, excessive bounce, and layout-shifting animations.

### Typography System
Use **Space Grotesk** for headings and interface labels, with **DM Sans** for body copy and metadata. Headings use lowercase, compact tracking, and strong weight contrast. Body text stays at a comfortable 1.65 line-height. Numbers and tags use a small mono treatment via **IBM Plex Mono** fallback.

### Brand Essence
Lieutenant.com is Jatin’s field notebook for building thoughtful software, physical systems, and playful experiments—made for collaborators who value both craft and curiosity.

Personality: **precise, inventive, unassuming**.

### Brand Voice
Headlines are short and specific. CTAs are warm but not salesy. Microcopy sounds like an engineer inviting someone into the process.

Example lines:
- “hi, jatin here — i turn curious problems into useful things.”
- “see the build notes”

### Wordmark & Logo
The mark is a compact compass-chevron built from two offset L shapes, suggesting a lieutenant insignia and a directional pointer. The wordmark uses a custom-spaced lowercase treatment in the interface, but the symbol remains the recognizable favicon/header mark.

### Signature Brand Color
**Lieutenant Mint — #a4f6c5**.

### Content Assumptions
The current build uses clearly marked illustrative placeholder content for certifications, projects, and PC hardware until Jatin supplies final details. It also includes obvious image replacement slots for the hero and about sections because the user has not uploaded personal photos yet. Social/contact links are included as editable placeholders for GitHub, LinkedIn, and “FakeNow.”
